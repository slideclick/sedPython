CS61A-Berkeley
==============
The CS 61 series is an introduction to computer science, with particular emphasis on software and on machines from a programmer's point of view. This first course concentrates mostly on the idea of abstraction, allowing the programmer to think in terms appropriate to the problem rather than in low-level operations dictated by the computer hardware. The next course, CS 61B, will deal with the more advanced engineering aspects of software, such as constructing and analyzing large programs. Finally, CS 61C concentrates on machines and how they carry out the programs you write.

--This description is taken from http://www-inst.eecs.berkeley.edu/~cs61a/fa13/about.html

I took class when it was taught in Scheme but now it is in Python.(A good idea!)
